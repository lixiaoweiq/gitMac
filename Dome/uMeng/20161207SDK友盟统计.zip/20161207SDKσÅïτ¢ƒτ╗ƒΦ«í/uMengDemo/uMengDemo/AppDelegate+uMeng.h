//
//  AppDelegate+uMeng.h
//  ZaiDaLi
//
//  Created by apple on 16/11/28.
//  Copyright © 2016年 enjoyor. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (uMeng)

/**
 友盟统计（channelId 友盟统计渠道：未发布测试使用"Web"  发布测试使用"" channelId为nil或@""时，默认会被当作@"App Store"渠道）（统计在模拟器和真机上均有效）
 
 @param appKey    友盟appKey
 @param channelId 友盟统计渠道：未发布测试使用"Web"  发布测试使用"App Store" （channelId 为nil或@""时,默认会被被当作@"App Store"渠道）
 */
- (void)uMengStartWithAppkey:(NSString *)appKey channelId:(NSString *)channelId;

@end
